using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class weapon_manager : MonoBehaviour
{
    const int weaponNum = 12; // ���� �� ����

    bool[] weaponNow = new bool[weaponNum]; // ���� ���⸦ ������ ��������
    int[] weaponPosition = new int[weaponNum] { 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3 }; // ���⸦ ���� �� �� �ִ� �� ��ȣ
    int[] prices = new int[weaponNum] { 3000, 5000, 7000, 10000, 15000, 20000, 25000, 30000, 35000, 40000, 45000, 5000}; // ���� ����
    public static bool getWeapon = false, setWeapon = false, setPoint1 = false, setPoint2 = false, setPoint3 = false;
    private int[] selectedWeapon = new int[3] { -1, -1, -1 };
    private GameObject storageDoor, houseDoor, pointButton, weaponImage;
    private GameObject defaultCanvas, storageCanvas, houseCanvas, pointCanvas;
    private TMP_Text weaponInfoText;
    public TMP_Text[] weaponButtonText = new TMP_Text[weaponNum];

    private weapon[] weaponClass = new weapon[weaponNum];

    private class weapon
    {
        protected string name;
        protected float attackDamage;
        protected float attackSpeed;
        protected int attackDistance;
        protected float damagePerSec;
        protected string information;
        
        public weapon (string _name, float _attackDamage, float _attackSpeed, int _attackDistance, float _damagePerSec)
        {
            name = _name;
            attackDamage = _attackDamage;
            attackSpeed = _attackSpeed;
            attackDistance = _attackDistance;
            damagePerSec = _damagePerSec;
            information = "null";
        }

        public void log()
        {
            Debug.Log(name);
        }
    }

    void Start()
    {
        storageDoor = GameObject.Find("storage_door");
        houseDoor = GameObject.Find("house_door");
        defaultCanvas = GameObject.Find("default_canvas");
        storageCanvas = GameObject.Find("storage_canvas");
        houseCanvas = GameObject.Find("house_canvas");
        pointCanvas = GameObject.Find("point_canvas");
        pointButton = GameObject.Find("point_weapon_button");
        weaponImage = GameObject.Find("weapon_image");
        weaponInfoText = GameObject.Find("weapon_info_text").GetComponent<TMP_Text>();
        defaultCanvas.SetActive(true);
        storageCanvas.SetActive(false);
        houseCanvas.SetActive(false);
        pointCanvas.SetActive(false);

        weaponClass[0] = new weapon("garlic", 10, 10, 10, 10);
        weaponClass[1] = new weapon("ax", 10, 10, 10, 10);
        weaponClass[2] = new weapon("shuriken", 10, 10, 10, 10);
        weaponClass[3] = new weapon("gun", 10, 10, 10, 10);
        weaponClass[4] = new weapon("bible", 10, 10, 10, 10);
        weaponClass[5] = new weapon("salt", 10, 10, 10, 10);
        weaponClass[6] = new weapon("cross", 10, 10, 10, 10);
        weaponClass[7] = new weapon("holyWater", 10, 10, 10, 10);
        weaponClass[8] = new weapon("redBeen", 10, 10, 10, 10);
        weaponClass[9] = new weapon("amulet", 10, 10, 10, 10);
        weaponClass[10] = new weapon("javelin", 10, 10, 10, 10);
        weaponClass[11] = new weapon("flameThrower", 10, 10, 10, 10);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F))
        {

            if (getWeapon)
            {
                defaultCanvas.SetActive(false);
                storageCanvas.SetActive(true);
                time_manager.isPaused = true;
            }
            else if (setWeapon)
            {
                defaultCanvas.SetActive(false);
                houseCanvas.SetActive(true);
                time_manager.isPaused = true;
            }

            else if (setPoint1)
            {
                defaultCanvas.SetActive(false);
                time_manager.isPaused = true;
                setPointWeapon(1);
            }
            else if (setPoint2)
            {
                defaultCanvas.SetActive(false);
                time_manager.isPaused = true;
                setPointWeapon(2);
            }

            else if (setPoint3)
            {
                defaultCanvas.SetActive(false);
                time_manager.isPaused = true;
                setPointWeapon(3);
            }
        }
    }

    private void setPointWeapon(int n)
    {
        //Debug.Log("open point " + n);
        pointCanvas.SetActive(true);
        for(int i = 0; i < weaponNum; i++)
        {
            pointButton.transform.GetChild(i).GetComponent<Button>().interactable = false;
            if (weaponNow[i] && weaponPosition[i] == n)
            {
                pointButton.transform.GetChild(i).GetComponent<Button>().interactable = true;
            }
        }
    }

    public void pushCloseButton()
    {
        storageCanvas.SetActive(false);
        houseCanvas.SetActive(false);
        pointCanvas.SetActive(false);
        defaultCanvas.SetActive(true);
        time_manager.isPaused = false;
    }

    public void pushWeaponButton(int n)
    {
        if (money_manager.returnMoney() >= prices[n] && !weaponNow[n])
        {
            money_manager.instance.minusMoney(prices[n]);
            money_manager.instance.textUpdate();
            weaponNow[n] = true;
            weaponButtonText[n].text = "SOLD OUT";
        }
    }
}
